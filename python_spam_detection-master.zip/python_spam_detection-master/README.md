# python_spam_detection
Solving SMS Spam Collection Dataset from kaggle

https://www.kaggle.com/uciml/sms-spam-collection-dataset

https://www.kaggle.com/kopylovlvad/scikit-onevsrestclassifier-and-tfidfvectorizer


# For use
```sh
python3 -m pip install -r requirements.txt
python3 app.py
open http://www.localhost:5000
```
